package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFF07111F.toInt())
        }
        val title = TextView(this).apply { text = "J.A.R.V.I.S"; textSize = 32f; setTextColor(0xFF64D8FF.toInt()); gravity = Gravity.CENTER }
        status = TextView(this).apply { text = "Hazırım. Konuşmak için düğmeye bas."; textSize = 18f; setTextColor(-1); gravity = Gravity.CENTER; setPadding(0, 36, 0, 36) }
        val button = Button(this).apply { text = "KONUŞ"; setOnClickListener { requestMic() } }
        layout.addView(title); layout.addView(status); layout.addView(button); setContentView(layout)
    }

    private fun requestMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 5)
        else listen()
    }

    override fun onRequestPermissionsResult(code: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, permissions, results)
        if (code == 5 && results.firstOrNull() == PackageManager.PERMISSION_GRANTED) listen()
        else status.text = "Mikrofon izni gerekli."
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.text = "Bu cihazda konuşma tanıma kullanılamıyor."; return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Dinliyorum…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Anlaşılıyor…" }
            override fun onError(error: Int) { status.text = "Dinleme bitti. Tekrar konuşmak için düğmeye bas." }
            override fun onResults(results: Bundle?) {
                val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                val answer = when {
                    heard.contains("merhaba", true) || heard.contains("selam", true) -> "Merhaba. Ben Jarvis. Nasıl yardımcı olayım?"
                    heard.contains("nasılsın", true) -> "İyiyim, teşekkür ederim."
                    heard.contains("youtube", true) -> "YouTube komutunu anladım. Uygulama açma özelliği sonraki sürümde eklenecek."
                    heard.contains("whatsapp", true) -> "WhatsApp komutunu anladım. Uygulama açma özelliği sonraki sürümde eklenecek."
                    else -> "Söylediğini duydum: $heard"
                }
                status.text = "Sen: $heard\n\nJarvis: $answer"
                tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        }
        recognizer?.startListening(intent)
    }

    override fun onInit(code: Int) { if (code == TextToSpeech.SUCCESS) tts?.language = Locale("tr", "TR") }
    override fun onDestroy() { recognizer?.destroy(); tts?.shutdown(); super.onDestroy() }
}
